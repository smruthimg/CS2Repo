import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.HashMap;
import java.util.Scanner;
/**
 * Class to represent the simulation of the circuit breaker
 * Created by Smruthi Gadenkanahalli on 2/14/2017.
 */
public class PanelSimulator {

    /*
    method to run the simulation
     */
public static void runSimulation() throws IOException {
    HashMap<String,Component> comps=new HashMap();
    String inp= null;
    Scanner reader = new Scanner(System.in);
    String[] inpArr=null;
    System.out.println("PanelSimulator input: ");
    while (true) {

        inp = reader.nextLine();
       inpArr=inp.split(" ");

            switch (inpArr[0]) {
                case "A":
                    switch (inpArr[1]) {
                        case "C":
                            if (!comps.containsKey(inpArr[2])){
//                        System.out.println("PanelSimulator input: " + inp);
                            if (inpArr[2].equals("main")) {
                                Circuit main = new Circuit("main", null, Integer.parseInt(inpArr[4]));
                                comps.put("main", main);
                                comps.get(inpArr[2]).add(main);

                                System.out.println(inpArr[2] + " added as root circuit");
                            } else {

                                Circuit cir1 = new Circuit(inpArr[2], comps.get(inpArr[3]), Integer.parseInt(inpArr[4]));
                                comps.put(inpArr[2], cir1);


                                if (comps.get(inpArr[3]) != null) {

                                    boolean cirAddRes=comps.get(inpArr[3]).add(cir1);
                                    if(cirAddRes) {
                                        System.out.println("PanelSimulator input: Circuit '" + inpArr[2] + "' added successfully");
                                    }
                                    else{
                                        System.out.println("PanelSimulator input: Circuit '" + inpArr[2] + "' failed add operation");

                                    }
                                } else {
                                    System.out.println("PanelSimulator input: Parent '" + inpArr[3] + "' does not exist");
                                }

                            }


//                            cir1.display("    ");
                            }
                            else{
                                System.out.println("PanelSimulator input: Component with name '"+ inpArr[2] + "' already exists.");
                            }
                            break;
                        case "R":
                            if (!comps.containsKey(inpArr[2])) {
//                        System.out.println("PanelSimulator input: " + inp);
                                Receptacle r1 = new Receptacle(inpArr[2], comps.get(inpArr[3]), Integer.parseInt(inpArr[4]));
                                comps.put(inpArr[2], r1);
//                        comps.get(inpArr[2]).display(" ");
                                if (comps.get(inpArr[3]) != null) {
                                    boolean cirRes=comps.get(inpArr[3]).add(r1);
                                    if(cirRes) {
//                        System.out.println(r1.children);
                                        System.out.println("PanelSimulator input: Receptacle '" + inpArr[2] + "' added successfully");
                                    }
                                    else{
                                        System.out.println("PanelSimulator input: Receptacle '" + inpArr[2] + "' failed add operation");

                                    }
                                } else {
                                    System.out.println("PanelSimulator input: Parent '" + inpArr[3] + "' does not exist");
                                }
                            }
                            else{
                                System.out.println("PanelSimulator input: Component with name '"+ inpArr[2] + "' already exists.");
                            }

//                        r1.display("   ");
                            break;
                        case "A":
                            if (!comps.containsKey(inpArr[2])) {
//                        System.out.println("PanelSimulator input: " + inp);
                                Appliance a1 = new Appliance(inpArr[2], comps.get(inpArr[3]), Integer.parseInt(inpArr[4]));
                                comps.put(inpArr[2], a1);
                                if (comps.get(inpArr[3]) != null ) {
                                    if((comps.get(inpArr[3]) instanceof Receptacle)) {
                                        boolean res = comps.get(inpArr[3]).add(a1);
                                        if (res) {
                                            System.out.println("PanelSimulator input: Appliance '" + inpArr[2] + "' added successfully");
                                        } else {
                                            System.out.println("PanelSimulator input: Appliance '" + inpArr[2] + "' failed add operation");
                                        }
                                    }
                                    else {
                                        System.out.println("PanelSimulator input: Appliance '" + inpArr[2] + "' failed add operation");
                                    }

                                } else {
                                    System.out.println("PanelSimulator input: Parent '" + inpArr[3] + "' does not exist");


                                }
                            }
                            else{
                                System.out.println("PanelSimulator input: Component with name '"+ inpArr[2] + "' already exists.");
                            }
                            break;
                    }
                    break;
                case "D":
                    Component c = comps.get(inpArr[1]);


//                System.out.println(comps.keySet());
//                System.out.println(comps.values());
                    if (comps.get(inpArr[1]) != null) {
                        System.out.println("PanelSimulator input: ");
                        comps.get(inpArr[1]).display("  ");
                    } else {
                        System.out.println("PanelSimulator input: Display failure: '" + inpArr[1] + "' does not exist");

                    }
                    break;
                case "T":
                    Component ap = comps.get(inpArr[1]);
                    if (comps.get(inpArr[1]) != null) {

                        if (ap instanceof Appliance) {

                            String res = ((Appliance) ap).toggleUsage();

                        }
                        else{
                            System.out.println("PanelSimulator input: Toggle failure: '" + inpArr[1] + "' is not an Appliance!");

                        }
                    }
                    else{
                        System.out.println("PanelSimulator input: Toggle failure: '" + inpArr[1] + "' does not exist");
                    }
//
                    break;
                case "Q":
//                System.out.println("PanelSimulator input: " + inp);
                    System.out.println("PanelSimulator input: Quitting!");
                    System.exit(0);
                    break;

            }
        }




}

/*
Main to execute the simulation
 */
    public static void main(String[] args) {
        // write your code here

        try {
            runSimulation();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
