import java.util.ArrayList;

/**
 * Representation of MultiComponent
 * Created by Smruthi Gadenkanahalli on 2/16/2017.
 */
public abstract class MultiComponent extends Component{

    //instance variable to store the child elements
    protected ArrayList<Component> children;
// Constructor
    protected MultiComponent(String name,Component source){
        super(name,source);
        children=new ArrayList<Component>();

    }

    /*
    Mehtod t0 reset the attributes of the MultiComponent
     */
    public void reset(){
        this.currCurrent=0;
//        source.currCurrent=this.currCurrent;
        for (Component c :children
             ) {
            c.reset();

        }
    }

}
