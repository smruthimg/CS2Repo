import java.sql.SQLOutput;

/**
 * Representation of a Appliance
 * Created by Smruthi Gadenkanahalli on 2/16/2017.
 */
public class Appliance extends Component {
//Member variables
    //instance variables
    private boolean inUse;
    private int reqCurrent;

    /*
    Constructor to initialize object
     */
    public Appliance(String name,Component source,int reqCurr){
        super(name,source);
        this.reqCurrent=reqCurr;
        this.currCurrent=0;
        this.inUse=false;

    }
/*
Method to add a component.
 */
    public boolean add(Component el){
        return false;

    }

    /*
    Method to display the attributes of Appliance in string format
     */
    protected void display(String offset){
        System.out.println(offset +offset+ "Appliance: " + name + " using " + this.currCurrent +" amps");
    }

    /*
    Method to get the inUse status of Appliance
     */
    public boolean getInUse(){
        return inUse;

    }

    /**
     * Method to reset the in use and current attributes of the appliance
     */

    public void reset(){
        this.inUse=false;
        this.currCurrent=0;


    }

    /**
     * method to toggle inUSe status and make the required current changes in parent circuit
     * @return name of appliance if there is an overload
     */
    public String toggleUsage(){

        inUse = !inUse;
        if (inUse){
            this.currCurrent=reqCurrent;
//           source.updateCurrent(this.currCurrent);
            System.out.println("PanelSimulator input: "+name+ " turned on.");
            return source.updateCurrent(this.currCurrent);
        }
//        this.currCurrent-=reqCurrent;

        System.out.println("PanelSimulator input: "+name+ " turned off.");
//        System.out.println(reqCurrent + "turning off amp");
        this.currCurrent=0;
        return source.updateCurrent(-reqCurrent);
    }
}
