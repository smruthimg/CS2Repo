/**
 * Representation of a Receptacle
 * Created by Smruthi Gadenkanahalli on 2/16/2017.
 */
public class Receptacle extends MultiComponent{

    //instance variable
    private int maxChildren;

    /*
    Constructor to initialize Receptacle object
     */
    public Receptacle(String name,Component source,int maxEl){
        super(name,source);
        maxChildren=maxEl;
    }

    /*
    Method to add the component to the Receptacle
     */
    public boolean 	add(Component el){
        if ((el instanceof Receptacle || el instanceof Appliance) && children.size()<maxChildren) {
//            System.out.println(children.size()+ " size of children");

            children.add(el);
//            this.currCurrent=el.currCurrent;
//            updateCurrent(el.currCurrent);
            return true;
        }
        return false;
    }

    /*
    Method to display the attributes of the Receptacle object
     */
    protected void display(String offset){
        System.out.println(offset+"Receptacle: " +name + " using " + this.currCurrent + " amps");
        for (Component c :children
                ) {

                c.display(offset);


        }

    }
}
