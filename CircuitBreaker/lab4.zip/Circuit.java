/**
 * Representation of a Circuit
 * Created by Smruthi Gadenkanahalli on 2/16/2017.
 */
public class Circuit extends MultiComponent {
    //Instance variables
    private int maxCapacity;

    //public constructor for Circuit class
    Circuit(String name, Component source, int maxCapacity){
        super(name,source);
        this.maxCapacity=maxCapacity;

    }

    /*
    Method to add a componenet to the circuit
     */
    public boolean 	add(Component el){
        if ((el instanceof Circuit && ((Circuit) el).maxCapacity<maxCapacity) || el instanceof Receptacle) {
//TODo check the max capacity before adding
            children.add(el);
            return true;
        }

        return false;
    }

    /*
    Method to dipslay the attributes of the Circuit class in string format
     */
    protected void display(String offset){
        System.out.println(offset+"Circuit: " +name + " using " +this.currCurrent + " out of " +maxCapacity + " available amps");
        for (Component c :children
             ) {
            if(!c.name.equals("main")) {
                c.display(offset+offset);
            }


        }

    }
/*
Method to update the current after the appliance is toggled
 */
    protected String updateCurrent(int deltaCurrent){
        this.currCurrent+=deltaCurrent;
//int temp=this.currCurrent+deltaCurrent;
//        System.out.println("temp = [" + temp + "]");
        if (this.currCurrent>maxCapacity){
            System.out.println(this.name+" circuit overload!" );
//            this.currCurrent=0;
            source.currCurrent-=(this.currCurrent-deltaCurrent);
//            System.out.println("curc" + currCurrent + this.currCurrent + source.currCurrent);
            this.reset();
//            updateCurrent(-deltaCurrent);
//            reset();
            for (Component c : children
                 ) {
                c.reset();

            }
            return name;
        }
       else{
//            this.currCurrent+=deltaCurrent;
            //Check for better way to do this

//            System.out.println("deltaCurrent = [" + deltaCurrent + "] current circuit" );
        }//this. current was 32 delta was 10 . this. current got updated to 10 instead of adding
//        }
        if (source!=null){
//            source.currCurrent+=deltaCurrent;
            return source.updateCurrent(deltaCurrent);
        }


        return null;
    }
}
