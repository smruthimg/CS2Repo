/**
 * Representation of Component
 * Created by Smruthi Gadenkanahalli on 2/16/2017.
 */
public abstract class Component {
    //instance variables
    protected int currCurrent;
    protected String name;
    protected Component source;
//Constructor
    protected Component(String name,Component source){
        this.name=name;
        this.source=source;
    }
// Abstract method to add component
    abstract boolean add(Component newElem);

    /*
    Method to display the attributes of the Component
     */
    void display(){

    }

    /*
    abstract method to display the attributes of the component with offset
     */
    protected abstract void display(String offset);

    /*
    Method to reset the component
     */
    abstract void reset();

    /*
    Method to update the current of the component
     */
    protected String updateCurrent(int deltaCurrent){
        this.currCurrent+=deltaCurrent;


        return source.updateCurrent(deltaCurrent);
    }





}
