package calendar.model;/**
 * Created by smrut on 4/13/2017.
 */

import javafx.application.Application;
import javafx.stage.Stage;

public class Kal extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

    }
}
