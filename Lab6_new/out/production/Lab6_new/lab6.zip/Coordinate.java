/*
File: Coordinate.java
Author: atd
 */

/**
 * Convenience class to represent a coordinate
 * of the playing board.
 *
 * @author atd
 */
public class Coordinate {

    private int row;
    private int col;

    /**
     * Coordinate constructor.
     * @param r first value (row) of the coordinate
     * @param c second value (column) of the coordinate
     */
    public Coordinate(int r, int c) {
        row = r;
        col = c;
    }

    /**
     * accessor for the row component of the coordinate
     * @return the value of the row component of the coordinate
     */
    public int getRow() {
        return row;
    }

    /**
     * accessor for the column component of the coordinate
     * @return the value of the column component of the coordinate
     */
    public int getCol() {
        return col;
    }

    /**
     * Overrides equals method.  Equality if both row and column
     * component are the same for the two objects.
     * @param oth the second Coordinate object to test equality against
     * @return true if two Coordinate objects are considered equal.
     */
    @Override
    public boolean equals(Object oth) {
        if(!(oth instanceof Coordinate)) {
            return false;
        }
        Coordinate c = (Coordinate)oth;

        return ((this.row == c.row) && (this.col == c.col));
    }

    /**
     * Override hashcode.
     * @return hash code value for this Coordinate object.
     */
    @Override
    public int hashCode() {
        // assuming 0 <= row,col <= 20, this will give a
        // unique hash code value for each possible Coordinate
        return row * 21 + col;
    }

    /**
     * Override toString.
     * @return a String representation of a Coordinate object.
     */
    @Override
    public String toString() {
        return "(Row: " + row + ", Col: " + col + ")";
    }
}
