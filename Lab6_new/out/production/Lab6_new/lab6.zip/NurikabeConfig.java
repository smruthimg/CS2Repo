import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Array;
import java.util.*;

/**
 * A class to represent a single configuration in the Nurikabe puzzle.
 *
 * @author Sean Strout @ RITCS
 * @author Smruthi Gadenkanahalli
 */
public class NurikabeConfig implements Configuration {

//Instance fields
    private String [][]  grid ;//the board
    private int dimX;//x coordinate dimension
    private int dimY;// y coordinate dimension
    private Coordinate lastCoor;//last coordinate placed
    private HashMap<Coordinate,List> islandCells;//list of island numbers
    private List<Coordinate> seaCells;//lst of sea cells

    private List<Coordinate> hashCells;//list of # palced

    /**
     * Construct the initial configuration from an input file whose contents
     * are, for example:<br>
     * <tt><br>
     * 3 3          # rows columns<br>
     * 1 . #        # row 1, .=empty, 1-9=numbered island, #=island, &#64;=sea<br>
     * &#64; . 3    # row 2<br>
     * 1 . .        # row 3<br>
     * </tt><br>
     * @param filename the name of the file to read from
     * @throws FileNotFoundException if the file is not found
     */
    public NurikabeConfig(String filename) throws FileNotFoundException {
        try (Scanner in = new Scanner(new File(filename))) {
            this.lastCoor=new Coordinate(0,0);
            this.seaCells=new ArrayList<Coordinate>();
            this.hashCells=new ArrayList<Coordinate>();
            this.islandCells=new HashMap<>();
            List<Coordinate> islList=new ArrayList<>();
//            this.islandCells.put(new Coordinate(-1,-1),islList);

            String line=in.nextLine();
            String [] chars=line.split(" ");
            this.dimX=Integer.parseInt(chars[0]);
            this.dimY=Integer.parseInt(chars[1]);
            this.grid=new String[dimX][dimY];
            for(int c=0;c<dimX;c++){
                String line2=in.nextLine();
                chars=line2.split(" ");
                if(chars.length>0){
                    for(int j=0; j<dimY;j++){

                        grid[c][j] = chars[j];
                        if(chars[j].matches("[0-9]"))
                        {
                            this.islandCells.put(new Coordinate(c, j), islList);

                        }
//                        if(chars[j].equals("1")) {
//                            if (j > 0) {
////                 System.out.println("left");
//                                this.grid[c][j-1]="@";
//                                seaCells.add(new Coordinate(c, j - 1));
//                            }
//                            if (c > 0 ) {
////                 System.out.println("top");
//                                this.grid[c-1][j]="@";
//                                seaCells.add(new Coordinate(c - 1, j));
//
//                            }
//                            if (j < dimY-1 ) {
////                 System.out.println("right");
//                                this.grid[c][j+1]="@";
//                                seaCells.add(new Coordinate(c, j + 1));
//                            }
//                            if (c < dimX -1) {
////                 System.out.println("bottom");
//                                this.grid[c+1][j]="@";
//                                seaCells.add(new Coordinate(c + 1, j));
////                 System.out.println(islandList);
//
//
//
//                            }
//                        }
//                            ArrayList<Coordinate> nebs=getNeighbors(new Coordinate(c, j));
//                            for (Coordinate coNeb:nebs
//                                 ) {
//                                seaCells.add(coNeb);
//                            }
//
//                        }



//                        else{
//                            if(grid[c][j]==null){
//                                grid[c][j] = chars[j];
//                            }
//                        }

//                    System.out.println(grid[c][j]);
                    }

                }


            }




            in.close();
        }


    }

    /**
     * The copy constructor takes a config, other, and makes a full "deep" copy
     * of its instance data.
     *
     * @param other the config to copy
     */
    protected NurikabeConfig(NurikabeConfig other) {



        this.dimX=other.dimX;
        this.dimY=other.dimY;
        this.grid=new String[other.dimX][other.dimY];
        for(int r=0 ; r<other.grid.length;r++){
            System.arraycopy(other.grid[r],0,this.grid[r],0,other.grid[0].length);
//            for (int i = 0; i <other.dimY ; i++) {
////                System.arraycopy(other.grid[r][i],0,this.grid[r][i],0,other.grid.length);
//                this.grid[r][i]=other.grid[r][i];
//            }

        }
        this.lastCoor=new Coordinate(other.lastCoor.getRow(),other.lastCoor.getCol());
        this.islandCells=other.islandCells;
        this.seaCells=new ArrayList<>(other.seaCells);
        this.hashCells=new ArrayList<>(other.hashCells);
//        System.out.println(this);

    }

    /**
     * Method to get he next successor to validate the board
     * @return 2 configs with @ and #
     */
    @Override
    public Collection<Configuration> getSuccessors() {

        LinkedList<Configuration> successor=new LinkedList<Configuration>();

        NurikabeConfig c1=new NurikabeConfig(this);
        NurikabeConfig c2=new NurikabeConfig(this);

        for (int i = 0; i < c1.dimX; i++) {
            for (int k = 0; k <c1.dimY ; k++) {

                if (c1.grid[i][k].equals(".")) {
                    c1.grid[i][k] = "#";
                    c2.grid[i][k]="@";
                    c1.lastCoor=new Coordinate(i,k);
                    c2.lastCoor=new Coordinate(i,k);
                    c2.seaCells.add(c2.lastCoor);
                    c1.hashCells.add(c1.lastCoor);

                    successor.add(c1);
                    successor.add(c2);

                    return successor;

                }
            }
        }
        return successor;
//        System.out.println(" successor" +c1.dimX);


    }

    /**
     * Method to validate the board
     * @return true if the board is valid else false
     */
    @Override
    public boolean isValid() {

        int row=lastCoor.getRow();
        int col=lastCoor.getCol();
        ArrayList<Coordinate> neighbors;
        neighbors=getNeighbors(lastCoor);
        ArrayList<Coordinate> neighbors2;
        int size;
         if(this.grid[row][col].equals("#")){
//             System.out.println("COunt of # : " + hashCells.size());
             for (Coordinate c:neighbors
                  ) {
                 size=recurDFS(c).size();
                 if(islandCells.keySet().contains(c) && size>Integer.parseInt(this.grid[c.getRow()][c.getCol()])){
                     return false;
                 }
                 if(this.grid[c.getRow()][c.getCol()].equals("#")){
                     neighbors2=getNeighbors(c);
                     for (Coordinate c1:neighbors2
                          ) {
                         size=recurDFS(c1).size();
                         if(islandCells.keySet().contains(c1) && size>=Integer.parseInt(this.grid[c1.getRow()][c1.getCol()])){
                             return false;
                         }

                     }
                 }
                 if(chaeckOverlap(lastCoor))return false;
             }
             ///check sum of islands are valid
             if(checkBoardFull() && !checkValidNumberCells()){
                 return false;

             }
//             if(checkBoardFull()  && checkPool()){
//                 return false;
//
//             }
        if(!getSumIsland())return false;


             return true;
         }

        //check if sea i valid
        else if(this.grid[row][col].equals("@")){
//            if(seaCells.contains(lastCoor))return true;

            int poolCount=0;

            if(col>0 && this.grid[row][col-1].equals("@")) {
                poolCount++;
            }
            if(row>0 && col>0 && this.grid[row-1][col-1].equals("@")){
                poolCount++;
            }
            if(row>0 && this.grid[row-1][col].equals("@")){
                poolCount++;
            }
            if(poolCount>=3){return false;}

             if(checkBoardFull()) {
                 if (!checkValidNumberCells()) {
                     return false;

                 }
                 if (!checkPool()) {
                     return false;

                 }
             }

            return true;

        }







        return false;
    }

    /**
     * Method to check if the solution is reached
     * @return true if the config is the final solution
     */
    @Override
    public boolean isGoal() {
        if(checkBoardFull())return true;

//        System.out.println("checking goal");
        return false;
    }

    /**
     * Returns a string representation of the puzzle, e.g.: <br>
     * <tt><br>
     * 1 . #<br>
     * &#64; . 3<br>
     * 1 . .<br>
     * </tt><br>
     */
    @Override
    public String toString() {

        String line="";
        for(int i=0;i<dimX;i++){
            for(int j=0;j<dimY;j++){
                line+=grid[i][j] + " ";

            }
            line+="\n";
        }
        return line;
    }

    /**
     * Method to ge tthe neighbors of the coordinate
     * @param co coordinate for which the neighbors has to be listed
     * @return list of coordinates
     */
    private ArrayList getNeighbors (Coordinate co){
        ArrayList islandList=new ArrayList();
        int c=co.getRow();
        int j=co.getCol();
//     System.out.println("c :" +c + " j: " + j);
        if (j > 0) {
//                 System.out.println("left");
            islandList.add(new Coordinate(c, j - 1));
        }
        if (c > 0 ) {
//                 System.out.println("top");
            islandList.add(new Coordinate(c - 1, j));

        }
        if (c >= 0 && j < dimY - 1) {
//                 System.out.println("right");
            islandList.add(new Coordinate(c, j + 1));
        }
        if (c < dimX - 1) {
//                 System.out.println("bottom");
            islandList.add(new Coordinate(c + 1, j));
//                 System.out.println(islandList);



        }


        return islandList;
    }

    /**
     * Implementation of depth first search to find the number of neighboring cells filled for the numbered cell
     * @param c Coordinate
     * @param visited list of cells with # in the neighboring cells
     */
    private void visitDFS(Coordinate c, Set<Coordinate> visited) {
        ArrayList<Coordinate> neighbor=getNeighbors(c);
//        System.out.println(" last coor "+ this.grid[lastCoor.getRow()][lastCoor.getCol()]);
        if(this.grid[c.getRow()][c.getCol()].equals("@")){
            for (Coordinate co1:neighbor) {
//            System.out.println("inside visitdfs  " + this.grid[co1.getRow()][co1.getCol()]);
                if (!visited.contains(co1) && this.grid[co1.getRow()][co1.getCol()].equals("@")) {
                    visited.add(co1);
                    visitDFS(co1, visited);
                }
            }
        }
else{
        for (Coordinate co1:neighbor) {
//            System.out.println("inside visitdfs  " + this.grid[co1.getRow()][co1.getCol()]);
            if (!visited.contains(co1) && this.grid[co1.getRow()][co1.getCol()].equals("#")) {
                visited.add(co1);
                visitDFS(co1, visited);
            }
        }

        }
    }

    /**
     * Recursive method to implement DFS
     * @param c Coordinate
     * @return set of neighboring cells
     */
    private HashSet<Coordinate> recurDFS(Coordinate c){

        HashSet<Coordinate> visted=new HashSet<>();
        visted.add(c);

        visitDFS(c,visted);
//        System.out.println(visted.size()+ " visited size " +" row:col " +  c.getRow() + c.getCol());
        return (visted);
    }


//    private void addToList(Coordinate c){
//        List<Coordinate> neigh=this.islandCells.get(c);
//        HashSet<Coordinate> visited=new HashSet<>();
//        visited.add(c);
//        ArrayList<Coordinate> getNeighborsList=getNeighbors(c);
//        if(Integer.parseInt(this.grid[c.getRow()][c.getCol()])>1){
//            for (Coordinate coor:getNeighborsList
//                    ) {
//                neigh.add(coor);
//
//            }
//
//        }
//    }

    /**
     * Mehtod to check if there is an overlap exists in the board
     * @param c Coordinate to check for
     * @return true of overlap exists
     */
    private boolean chaeckOverlap(Coordinate c){
        ArrayList<Coordinate> origin=getNeighbors(c);
        Set<Coordinate> islandKeys=this.islandCells.keySet();
        int neighborCount=0;
        for (Coordinate c2:origin
                ) {
            if(this.grid[c2.getRow()][c2.getCol()].matches("[0-9]")){
                neighborCount++;
            }

//           for (Coordinate key:islandKeys
//                ) {
//               if()
//           }
//               if(islandKeys.contains(coordinate)){
//                   neighborCount++;
//               }
//           }
            if(neighborCount>1){
                return true;
            }



        }
        return false;
    }

    /**
     * Method to check if board is full
     * @return true if board is full
     */
    private boolean checkBoardFull(){
        if(this.grid[dimX-1][dimY-1].matches("[0-9]")){
            if(this.grid[dimX-1][dimY-2].equals(".")){
                return false;
            }
        }
        else if(this.grid[dimX-1][dimY-1].equals(".")){
            return false;
        }

    return true;
    }

    /**
     * Method to check if the numbered cells have valid neighboring cells
     * @return true if its valid
     */
    private boolean checkValidNumberCells(){
        Set<Coordinate> numbered=islandCells.keySet();
        int size;
        for (Coordinate c:numbered
             ) {
            size=recurDFS(c).size();
            if(size!=Integer.parseInt(this.grid[c.getRow()][c.getCol()]))return false;

        }
        return true;
    }

    /**
     * Mehtod tto check number cells with # is valid
     * @return  true if valid
     */
    private boolean getSumIsland(){
        Set<Coordinate> numbered=islandCells.keySet();
        int size=0;
        int countHash;
        int value;
        int islandRemaining=0;
        int visited;
//        System.out.println("COunt of # : " + hashCells.size());
        for (Coordinate c:numbered
             ) {
            value=Integer.parseInt(this.grid[c.getRow()][c.getCol()]);

                size +=value-1;

//            visited=recurDFS(c).size();
//            if(visited<Integer.parseInt(this.grid[c.getRow()][c.getCol()])){
//                islandRemaining++;
//            }

        }
        countHash=hashCells.size();
//        for (int i = 0; i < dimX; i++) {
//            for (int j = 0; j <dimY ; j++) {
//                if(this.grid[i][j].equals("#")){
//                    countHash++;
//                }
//                if(this.grid[i][j].equals(".")){
//                    countDot++;
//                }
//            }
//
//        }
        if(countHash>size)return false;
        return true;

    }

//    private boolean checkIsland(){
//        int count=0;
//        int recur=0;
//        ArrayList<Coordinate> origin;
//        Coordinate track;
//        int x,y;
//
//        for (int i = 0; i < dimX; i++) {
//            for (int j = 0; j <dimY ; j++) {
//                if(this.grid[i][j].equals("#")){
//                    origin=getNeighbors(new Coordinate(i,j));
//                    for (Coordinate c:origin
//                         ) {
//                        if(this.grid[c.getRow()][c.getCol()].equals("#")){
//                            count++;
//                            x=c.getRow();
//                            y=c.getCol();
////                            track=new Coordinate(c.getRow(),c.getCol());
//                        }
//
//                    }
//
//                }
//            }
//
//        }
//    }

    /**
     * Method to check if there are disconnected sea component
     * @return true if connected; false if disconnected
     */
    private boolean checkPool(){
        int countSea;
        int recur;
//        System.out.println("Seac Cells :" + seaCells.get(0));
        countSea=seaCells.size();
//        Coordinate c=new Coordinate(-1,-1);
//        for (int i = 0; i < dimX; i++) {
//            for (int j = 0; j <dimY ; j++) {
//                if(this.grid[i][j].equals("@")){
//                    countSea++;
//                    c=new Coordinate(i,j);
//                }
//            }
//        }
//        if(seaCells.get(0).getCol()>=0){
        recur=recurDFS(seaCells.get(0)).size();
//            System.out.println(recur+ " pool size" + " count sea " + countSea);
        if (countSea!=recur)return false;
//        }


        return true;
    }
}
