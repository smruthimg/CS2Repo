/**
 * representation of a Professor
 * Created by Smruthi Gadenkanahalli on 2/27/2017.
 */
public class Professor extends User {
    public Professor(String username){
        super(username,UserType.PROFESSOR,new ProfessorComparator());
    }
}
