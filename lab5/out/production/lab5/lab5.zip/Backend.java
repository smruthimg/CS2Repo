import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Scanner;

/**
 * Representation of SIS Backend
 * Created by Smruthi Gadenkanahalli on 2/27/2017.
 */
public class Backend {
//Instance fields
    private CourseDB courseDB;
    private UserDB userDB;

    //Constructor
    public Backend(String courseFile, String professorFile, String studentFile) throws FileNotFoundException{
        this.courseDB=new CourseDB();
        this.userDB=new UserDB();
        initializeCourseDB(courseFile);
        initializeUserDB(professorFile,studentFile);



    }

    /**
     * Method to initialize Course DB
     * @param courseFile
     * @throws FileNotFoundException
     */
    private void initializeCourseDB(String courseFile)throws FileNotFoundException {
        try (Scanner in = new Scanner(new File(courseFile))) {
//            int courseid=0;
            while (in.hasNext()) {
                String[] fields = in.nextLine().split(",");
//                courseid++;
//                addCourse();
                courseDB.addValue(new Course(Integer.parseInt(fields[0]),fields[1],Integer.parseInt(fields[2])));

            }
        }

    }
    // fields[0] is the course id, as a String
    // fields[1] is the course name, as a String
    // fields[2] is the course level, as a String

    /**
     * Mehtod to initialize Student and Professor
     * @param professorFile
     * @param studentFile
     * @throws FileNotFoundException
     */
    private void initializeUserDB(String professorFile,
                                  String studentFile)throws FileNotFoundException{
        try (Scanner in = new Scanner(new File(""+professorFile))) {
        while (in.hasNext()) {
            String[] fields = in.nextLine().split(",");
            Professor p=new Professor(fields[0]);
            addCourse(p,Arrays.copyOfRange(fields,1,fields.length));
            //TODO add to userdb
            userDB.addValue(p);


        }

    }
        try (Scanner in = new Scanner(new File(studentFile))) {
            while (in.hasNext()) {
                String[] fields = in.nextLine().split(",");
                Student s=new Student(fields[0]);
                addCourse(s, Arrays.copyOfRange(fields,1,fields.length));
                userDB.addValue(s);


            }
        }

    }

    /**
     * Method to add a course to user
     * @param user
     * @param courseIds
     */
    public void addCourse(User user,String[] courseIds){
        if(user instanceof Professor){
            Professor u=(Professor)user;
            for (String c: courseIds
                    ) {courseDB.getValue(Integer.parseInt(c)).addProfessor(u.getUsername());
                    user.addCourse(courseDB.getValue(Integer.parseInt(c)));

            }
        }
        else{
            Student u=(Student)user;
            for (String c: courseIds
                    ) {courseDB.getValue(Integer.parseInt(c)).addStudent(u.getUsername());
                user.addCourse(courseDB.getValue(Integer.parseInt(c)));

            }
        }



    }

    /**
     * Method to check if course exists
     * @param id
     * @return boolean
     */
    public boolean courseExists(int id){

        return courseDB.hasKey(id);
    }

    /** Method to enroll a student into a course
     *
     * @param username
     * @param courseId
     * @return boolean
     */
    public boolean enrollStudent(String username,
                                   int courseId){
        Course c=getCourse(courseId);
        User u=userDB.getValue(username);
        if(c!=null && u instanceof Student ){
            Student s=(Student)u;
            Collection<Course> cs=s.getCourses();
            for (Course c1: cs
                 ) {if(c1.getId()==courseId){
                System.out.println("student " + username + " already enrolled in course");
                return false;
            }

            }

            s.addCourse(c);
            c.addStudent(username);
            return true;
        }

        return false;

    }

    /**
     * Method to get all courses
     * @return Course
     */
    public Collection<Course> getAllCourses(){
        return  courseDB.getAllValues();

    }

    /**
     * Mehtod to get all users
     * @return User
     */
    public Collection<User> getAllUsers(){
        return userDB.getAllValues();
    }
    public boolean isStudent(String username){
        if(userExists(username)){
            if(userDB.getValue(username) instanceof Student){

                return true;
            }
        }

        return false;
    }

    /**
     * Method to get a Course
     * @param id
     * @return Course
     */
    public Course getCourse(int id){
        if(courseExists(id)){
            return courseDB.getValue(id);
        }
        return null;
    }

    /**
     * Method to unenroll a student
     * @param username
     * @param courseId
     * @return boolean
     */
    public boolean unenrollStudent(String username,
                                   int courseId){
        boolean cRemove=false;
        boolean sRemove=false;

        if(courseExists(courseId) && userExists(username) && isStudent(username)){
             cRemove=courseDB.getValue(courseId).removeStudent(username);
             if(cRemove) {
                 sRemove = userDB.getValue(username).removeCourse(getCourse(courseId));
             }

        }

        return cRemove && sRemove;
    }

    /**
     * Mehtod to check if user exists
     * @param username
     * @return boolean
     */
    public boolean userExists(String username){
//        if(userDB.hasKey(username))
        return userDB.hasKey(username);
    }

    /**
     * Mehtod to get the courses for the user
     * @param username
     * @return
     */
    public Collection<Course> getCoursesUser(String username){
        return userDB.getValue(username).getCourses();
    }


}
