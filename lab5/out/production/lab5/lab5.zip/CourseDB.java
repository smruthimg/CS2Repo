import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Represenatation od a Course DB
 * Created by Smruthi Gadenkanahalli on 2/27/2017.
 */

public class CourseDB implements DB<Integer,Course> {

    @Override
    /**
     * Method to add the value tot he Course Map
     */
    public Course addValue(Course value) {
        for (Map.Entry<Integer,Course> c: courses.entrySet()){
            if(c.getValue()==value){
                return c.getValue();
            }
        }
        courses.put(value.getId(),value);
        return null;
    }

    @Override
    /**
     * Mehtod to get all values in the Course Collection
     */
    public Collection<Course> getAllValues() {
        return courses.values();
    }

    /**
     * Method t get value for given key
     * @param id
     * @return
     */
    @Override
    public Course getValue(Integer id) {
        if (hasKey(id)){
            return courses.get(id);
        }
        return null;
    }

    /**
     * Method to check if the Course id exists
     * @param key
     * @return boolean
     */
    @Override
    public boolean hasKey(Integer key) {
        return courses.containsKey(key);
    }
    private HashMap<Integer,Course> courses;

    /**
     * Constructor
     */
    public CourseDB(){
        courses=new HashMap<Integer,Course>();
    }

}
