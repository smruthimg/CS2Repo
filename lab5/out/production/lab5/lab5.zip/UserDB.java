import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Respresentation of User DB
 * Created by Smruthi Gadenkanahalli on 2/27/2017.
 */
public class UserDB implements DB<String,User> {
    //Instance Fields
    private HashMap<String,User> users;

    //Constructor
    public UserDB(){
        this.users=new HashMap<String,User>();
    }


    /**
     * Method to add value
     * @param value
     * @return User
     */
    @Override
    public User addValue(User value) {
        for (Map.Entry<String,User> u: users.entrySet()){
            if(u.getValue()==value){
                return u.getValue();
            }
        }
        users.put(value.getUsername(),value);
        return null;
    }

    /**
     * Method to get all users
     * @return uSer
     */
    @Override
    public Collection<User> getAllValues() {
        return users.values();
    }

    /**
     * Method to get the user
     * @param key
     * @return user
     */
    @Override
    public User getValue(String key) {
        if(hasKey(key)) {
            return this.users.get(key);
        }
        return null;
    }

    /**
     * Method to check if the user exists
     * @param key
     * @return
     */
    @Override
    public boolean hasKey(String key) {
        return this.users.containsKey(key);
    }
}
