import java.util.Comparator;

/**
 * Student Comparator
 * Created by Smruthi Gadenkanahalli on 3/2/2017.
 */
public class StudentComparator implements Comparator<Student> {
    @Override
    public int compare(Student o1, Student o2) {
        return o1.getUsername().compareTo(o2.getUsername());
    }
}
