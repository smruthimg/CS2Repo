import java.util.Collection;

/**
 * Interface to implement DB
 * Created by Smruthi Gadenkanahalli on 2/27/2017.
 */
public interface DB<K,V> {
    V addValue(V value);
    Collection<V> getAllValues();
    V getValue(K key);
    boolean hasKey(K key);
}
