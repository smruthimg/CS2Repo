import java.security.PublicKey;
import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;

/**
 * Representation of a User
 * Created by Smruthi Gadenkanahalli on 2/27/2017.
 */
public class User implements Comparable<User> {
    //Instance fields
    private  String username;
//User type enumeration
    public enum UserType {
        PROFESSOR,
        STUDENT
    }
    private TreeSet<Course> courses;
    private User.UserType type;

    //Constructor
    public User(String username, User.UserType type, Comparator comp ){

        this.username=username;
        this.type=type;

        this.courses=new TreeSet<Course>();

    }

    /**
     * Overridden method for Comparable interface
     * @param o
     * @return int
     */
    @Override
    public int compareTo(User o) {

        return this.username.compareTo(o.username);

    }

    /**
     * Method to check the objeccts are equal
     * @param other
     * @return boolean
     */
    public boolean equals(Object other){
        if( other instanceof User){
           User u=(User)other;
           return this.username.equals(u.username);
        }
        return false;
    }

    /**
     * Methos to get the courses
     * @return
     */
    public Collection<Course> getCourses(){
        return this.courses;
    }

    /**
     * Methos to add the course
     * @param course
     * @return boolean
     */
    boolean addCourse(Course course){
        courses.add(course);
        return true;
    }

    /**
     * Accessor to get type
     * @return
     */
    public  User.UserType getType(){
        return type;
    }

    /**
     * accessor to get username
     * @return username
     */
    public String getUsername(){
        return username;

    }

    /**
     * Methos to generate hash code
     * @return int
     */
    public int hashCode(){
        return username.hashCode();
    }

    /**
     * Method to remove the course
     * @param course
     * @return boolean
     */
    public boolean removeCourse(Course course){
        if(courses.contains(course)){
            courses.remove(course);
            return true;
        }
        return false;
    }

    /**
     * Method to represent the user in string format
     * @return string
     */
    public String toString(){
        return "User{username= "+this.getUsername() + " ,type= "+ this.getType() + " ,courses= "+ courses + "}";
    }
}
