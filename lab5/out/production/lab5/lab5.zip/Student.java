import java.util.Comparator;

/**
 * Representation of a student
 * Created by Smruthi Gadenkanahalli on 2/27/2017.
 */
public class Student extends User {
    public Student(String username){
        super(username,UserType.STUDENT, new StudentComparator() );
    }


}
