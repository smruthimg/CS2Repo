import java.util.Comparator;

/**
 * Professor Compartor
 * Created by Smruthi Gadenkanahalli on 3/2/2017.
 */
public class ProfessorComparator implements Comparator<Professor> {
    @Override
    public int compare(Professor o1, Professor o2) {
        return o1.getUsername().compareTo(o2.getUsername());
    }
}
