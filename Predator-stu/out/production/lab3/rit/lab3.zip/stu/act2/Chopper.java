package rit.stu.act2;

import rit.cs.Stack;
import rit.stu.act1.StackNode;

/**
 * Representation of Chopper that is used to rescue the hotage and carry soldiers
 * Created by Smruthi Gadenkanahalli on 2/10/2017.
 */
public class Chopper {
    //member fields
    //A stack to store payers
    private Stack<Player> chopper;
    //Single instance of Maximum occupancy
    public static int MAX_OCCUPANCY=6;
    // number of passengers in the chopper
    private int numPassengers;
    // Number of hostages rescued
    private int numRescued;

    /**
     * Constructor for Chopper to initialize chopper and member fields
     */
    public Chopper(){
        chopper=new StackNode<>();
        numRescued=0;
        numPassengers=0;
    }

    /**
     * Method to board passengers to chopper
     * @param player Player to be added to the chopper
     */
    public void boardPassenger(Player player){
        if(isFull() ) {
            rescuePassengers();
//
        }
        chopper.push(player);
        System.out.println(player + " boards the chopper");
        numPassengers++;
        //  rescuePassengers();




    }

    /**
     * Method to get the number of Hostages rescued
     * @return Integer
     */
    public int getNumRescued(){
        return numRescued;
    }


    /**
     * Method to check if the Choppe ris empth
     * @return Boolean
     */
    public boolean isEmpty(){
        return numPassengers==0;
    }

    /**
     * Method to check if the chopper is full
     * @return Boolean
     */
    public boolean isFull(){
        return (numPassengers==MAX_OCCUPANCY);
    }

    /**
     * Method to simulate the rescue operation
     */
    public void rescuePassengers(){
        if(!isEmpty()  ){
            while(numPassengers>0){
                System.out.println("Chopper transported " + chopper.pop() +" to safety!");
                numRescued++;
                numPassengers--;
            }
        }

    }
}
