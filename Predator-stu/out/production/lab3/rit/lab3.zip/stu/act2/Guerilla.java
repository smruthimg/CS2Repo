package rit.stu.act2;

/**
 * A class to represent the player Guerilla
 * Created by Smruthi Gadenkanahalli on 2/10/2017.
 */
public class Guerilla implements Player{
    //constant
    public static final int CHANCE_TO_BEAT_SOLDIER=20;
    private int id;

    /**
     * Constructor to initialize id for Guerilla object
     * @param id the id of guerilla object
     */
    public Guerilla(int id){
        this.id=id;
    }

    /**
     * Overriding Victory method from player to display victory message for Guerilla
     * @param player the player  the Guerilla is fighting
     */
    @Override
    public void victory(Player player) {
        System.out.println("Guerilla #"+ id+ " yells, 'Victoria sobre " + player +"!'");

    }

    /**
     * Overriding Defeat method from player to display defeat message for Guerilla
     * @param player the player  the Guerilla is fighting
     */
    @Override
    public void defeat(Player player) {
        System.out.println("Guerilla #"+id+ " cries, 'Derrotado por " + player+"!'");
    }

    /**
     * Method to represent the Guerilla object in string format
     * @return a String
     */
    @Override
    public String toString() {
        return "Guerilla #" + id;
    }
}
