package rit.stu.act2;

/**
 * A class to respresent the player Predator
 * Created by Smruthi Gadenkanahalli on 2/10/2017.
 */
public class Predator implements Player{
    //Data member
    //Single instance of chance to beat hostage value
    public static final int CHANCE_TO_BEAT_HOSTAGE=75;

    //Single instance of chance to beat soldier value

    public static final int CHANCE_TO_BEAT_SOLDIER=50;

    public Predator(){

    }
    /**
     * Overriding Defeat method from player to display defeat message for Predator
     * @param player the player  the Predator is fighting
     */
    @Override
    public void victory(Player player) {
        System.out.println("The predator yells out in triumphant victory over " + player+"!" );

    }
    /**
     * Overriding Defeat method from player to display defeat message for Predator
     * @param player the player  the Predator is fighting
     */
    @Override
    public void defeat(Player player) {
        System.out.println("The predator cries out in glorious defeat to " + player  +"!");

    }

    /**
     * Method to represent the Predator object in string format
     * @return a String
     */
    public String toString()
    {
        return "Predator";
    }
}
