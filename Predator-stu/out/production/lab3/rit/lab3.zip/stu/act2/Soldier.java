package rit.stu.act2;

/**
 * A class to represent the Soldier
 * Created by Smruthi Gadenkanahalli on 2/10/2017.
 */
public class Soldier implements Player {
    // Id for soldier
    private int id;

    /**
     * Constructor to initialize the id for Soldier
     * @param id Id for soldier object
     */
    public Soldier(int id){
        this.id=id;
    }

    /**
     * Overriding Victory mrthod from player to display victory message for Soldier
     * @param player the player  the soldier is fighting
     */
    @Override
    public void victory(Player player) {
        System.out.println("Soldier #"+this.id+ " yells, 'Sieg über " + player +"!'");

    }

    /**
     * Overriding Defeat mrthod from player to display defeat message for Soldier
     * @param player the player  the soldier is fighting
     */

    @Override
    public void defeat(Player player) {
        System.out.println("Soldier #"+this.id+ " cries, 'Besiegt von " + player+"!'");
    }

    public String toString(){
        return "Soldier #"+id;
    }
}
