package rit.stu.act2;

import rit.cs.Queue;
import rit.cs.QueueList;
import rit.stu.act1.QueueNode;

/**
 * The representation of the Bunker to hold the Guerilla ans hostage
 * Created by Smruthi Gadenkanahalli on 2/10/2017.
 */
public class Bunker {
// Member fields
    private Queue<Soldier> bunker;
    private int numSoldiers;

    /**
     * The constructor to initialize the Bunker.
     * @param numSoldiers integer.
     */
    public Bunker(int numSoldiers){
        Soldier soldier;
        bunker=new QueueList<Soldier>();
        for (int i = 1; i <=numSoldiers ; i++) {

            soldier=new Soldier(i);
            fortifySoldiers(soldier);

        }
    }

    /**
     * Method to check if the bunker has soldiers
     * @return Boolean
     */
    public boolean hasSoldiers(){
        return bunker.empty();
    }

    /**
     * Method to get the number of soldiers remaining in the bunker
     * @return integer
     */
    public int getNumSoldiers(){
        return numSoldiers;
    }

    /**
     * Method to deploy next soldier to enemy base
     * @return Soldier
     */
    public Soldier deployNextSoldier(){
        if(!bunker.empty()) {
            numSoldiers--;
            return bunker.dequeue();
        }
        return null;

    }

    /**
     * Method to add the soldier back into the bunker
     * @param soldier Soldier object
     */
    public void fortifySoldiers(Soldier soldier){
        bunker.enqueue(soldier);
        numSoldiers++;
    }
}
