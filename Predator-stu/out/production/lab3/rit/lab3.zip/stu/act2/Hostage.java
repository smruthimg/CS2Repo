package rit.stu.act2;

/**
 * Representation of the Hostage implementing Player interface
 * Created by Smruthi Gadenkanahalli on 2/10/2017.
 */
public class Hostage implements Player {
    //Player id
    private int id;
    //Public constructor
    public Hostage(int id) {
        this.id=id;
    }


    /**
     * Overriding Victory method from player to display victory message for Hostage
     * @param player the player  the HOstage is fighting
     */
    @Override
    public void victory(Player player) {
        System.out.println("Hostage #"+id+" yells, 'Victory over " + player + "!'");

    }

    /**
     * Overriding Defeat method from player to display defeat message for Hostage
     * @param player the player  the HOstage is fighting
     */
    @Override
    public void defeat(Player player) {
        System.out.println("Hostage #"+id+" cries, 'Defeated by " + player + "!'");

    }

    /**
     * Method to represent the Hostage object in string format
     * @return a String
     */
    @Override
    public String toString() {
        return "Hostage #" +
                 id
                ;
    }
}
