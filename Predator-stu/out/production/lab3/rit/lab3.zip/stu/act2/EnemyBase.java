package rit.stu.act2;

import rit.cs.Queue;
import rit.cs.QueueList;
import rit.cs.Stack;
import rit.cs.StackList;

/**
 * A representation of the enemy base that holds the guerillas and the hostages
 *
 * Created by Smruthi Gadenkanahalli on 2/10/2017.
 */
public class EnemyBase {
    //data members
    // instance of Guerilla
    private Queue<Guerilla> guerillas;
    // instance of Hostage
    private Stack<Hostage> hostages;
    //Number of Gurerillas
    private int numGuerillas;
    //Number of Hostages
    private int numHostages;

    /**
     * Constructor to initialize the data memebers and add hostages to the stack and guerillas to queue
     * @param numHostages number of hostages in enemy base
     * @param numGuerillas number of guerilla in base
     */
    public EnemyBase(int numHostages,int numGuerillas){
        this.numGuerillas=numGuerillas;
        this.numHostages=numHostages;
        guerillas=new QueueList<Guerilla>();
        hostages=new StackList<Hostage>();
        for (int i = 1; i <= numHostages; i++) {
            Hostage newHostage= new Hostage(i);
            hostages.push(newHostage);
        }
        for (int i = 1; i <=numGuerillas ; i++) {
            Guerilla newGuerilla= new Guerilla(i);
            guerillas.enqueue(newGuerilla);
        }
    }

    /**
     * Method to add the guerilla to the queue
     * @param guerilla guerilla object to be added
     */
    private void addGuerilla(Guerilla guerilla){
        this.guerillas.enqueue(guerilla);
        numGuerillas++;

    }

    /**
     * Method to add the hostage to the stack
     * @param hostage Hostage object
     */
    private void addHostage(Hostage hostage){
        this.hostages.push(hostage);
        numHostages++;
    }

    /**
     * remove and return the guerilla at the front of the queue
     * @return guerilla object
     */
    private Guerilla getGuerilla(){
        assert !guerillas.empty();
        numGuerillas--;

        return this.guerillas.dequeue();
    }

    /**
     * remove and return the Hostage at the top of the stack
     * @return Hostage object
     */
    private Hostage getHostage(){
        assert !hostages.empty();
        numHostages--;
        return this.hostages.pop();
    }

    /**
     * method to get eh total umber of guerillas int he queue
     * @return integer value
     */
    public int getNumGuerillas(){
        return numGuerillas;
    }

    /**
     * method to get the total number of hostages int he stack
     * @return integer value
     */
    public int getNumHostages(){
        return numHostages;

    }

    /**
     * Method to simulate the rescue operation
     * @param soldier Soldier chosen to rescue the Hostage
     * @return Hostage object
     */
    public Hostage rescueHostage(Soldier soldier){
        System.out.println(  soldier + " enters enemy base...");
//        System.out.println(nextHostage);
        if(numHostages>0) {
            Hostage h1 = getHostage();
            if (numGuerillas==0) {
//            hostages.push(h1);
                return h1;

            } else {
                Guerilla g1 = getGuerilla();
                //  roll dice
                int result = Battlefield.nextInt(1, 100);
                System.out.println(soldier + " battles " + g1 + " who rolls a " + result);
                if (Guerilla.CHANCE_TO_BEAT_SOLDIER < result) {
                    soldier.victory(g1);
                    g1.defeat(soldier);

                    return h1;
                } else {
                    g1.victory(soldier);
                    soldier.defeat(g1);
                    addHostage(h1);
                    addGuerilla(g1);

                }
            }
        }
        return null;
    }

}
