package rit.stu.act2;

/**
 * An interface to represent a player
 * Created by Smruthi Gadenkanahalli on 2/10/2017.
 */
public interface Player {
    /**
     * Method to display the victory message
     * @param player
     */
    void victory(Player player);

    /**
     * Method to display the defeat message
     * @param player
     */
    void defeat (Player player);
}
