package rit.stu.act1;

import rit.cs.Node;
import rit.cs.Queue;

/**
 * A queue implementation that uses a Node to represent the structure.
 * @param <T> The type of data the queue will hold
 * @author Sean Strout @ RIT CS
 * @author Smruthi Gadenkanahalli
 */
public class QueueNode<T> implements Queue<T> {
    /**
     * Create an empty queue.
     */
    private Node<T> front;
    private Node<T> back;
    public QueueNode() {
        this.front=null;
        this.back=null;
    }

    @Override
    public T back() {
        assert !empty();
        return this.back.getData();

    }

    @Override
    public T dequeue() {
        assert !empty() ;
        T element = this.front.getData();
//            Node<T> temp = this.front.getNext()
        this.front=this.front.getNext();
//        System.out.println("Dequiing test"+this.front.getData());
//        this.back=this.back.getNext();


        return element;
    }

    @Override
    public boolean empty() {
        return this.front==null;
    }

    @Override
    public void enqueue(T element) {
        Node<T> node=new Node<T>(element,null);
        if(this.front==null){
            this.front=node;
            this.back=front;
        }
        else{

            this.back.setNext(node);
        }
        this.back=node;

    }

    @Override
    public T front() {
        assert !empty();
        return this.front.getData();
    }
}
