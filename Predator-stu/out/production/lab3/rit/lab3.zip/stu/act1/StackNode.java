package rit.stu.act1;

import rit.cs.Stack;
import rit.cs.Node;

/**
 * A stack implementation that uses a Node to represent the structure.
 * @param <T> The type of data the stack will hold
 * @author Sean Strout @ RIT CS
 * @author Smruthi Gadenkanahalli
 */
public class StackNode<T> implements Stack<T> {

    /**
     * Create an empty stack.
     */
    private Node<T> top;
    public StackNode() {
        this.top=null;

    }

    @Override
    public boolean empty() {

        return this.top==null;
    }

    @Override
    public T pop() {
        assert !empty();
        T element=this.top.getData();
//        System.out.println("popping "+element);
        Node<T> next=this.top.getNext();
        this.top=next;
//        System.out.println("next "+next);


        return element;
    }

    @Override
    public void push(T element) {
          if (!empty()) {
              Node<T> node = new Node<T>(element, top);
              this.top = node;
          }
          else{
              Node<T> node = new Node<T>(element, null);
              this.top = node;
              }

//        System.out.println("element = [" + element + "]" + top.getData());

    }

    @Override
    public T top()
    {
        assert !empty();
        return this.top.getData();

    }



}
